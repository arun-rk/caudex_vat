UPDATE `tec_settings` SET `version` = '4.0.11' WHERE `setting_id` = 1;
